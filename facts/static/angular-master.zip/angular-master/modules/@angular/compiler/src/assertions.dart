library angular2.core.util.asserions;

void assertArrayOfStrings(String identifier, Object value) {}
