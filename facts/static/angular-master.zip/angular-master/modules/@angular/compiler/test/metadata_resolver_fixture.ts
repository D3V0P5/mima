import {Component} from '@angular/core';

@Component({styles: <any>('foo'), template: ''})
export class MalformedStylesComponent {
}
