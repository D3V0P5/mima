
export const styles = /*@ts2dart_const*/[`.greenStyle[_ngcontent-a-1] { color: green; }`];
