// Verify we don't try to extract metadata for .d.ts files
export declare var a: string;
