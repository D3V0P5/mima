export function wrapInArray(value: any): any[] {
  return [value];
}