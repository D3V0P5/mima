library angular2.test.core.dom.shim_spec;

main() {
  // not relevant for dart.
}
