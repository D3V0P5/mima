library angular2.test.util.decorators_dart_spec;

main() {
  // not relavant for dart.
}
