library angular2.test.facade.observable_spec;

main() {
  //stub to ignore JS Observable specific tests
}
