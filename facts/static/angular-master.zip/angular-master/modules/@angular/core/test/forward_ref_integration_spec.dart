/// This file contains tests that make sense only in Dart
library angular2.test.core.forward_ref_integration_spec;

main() {
  // Don't run in Dart as it is not relevant, and Dart const rules prevent us from expressing it.
}
