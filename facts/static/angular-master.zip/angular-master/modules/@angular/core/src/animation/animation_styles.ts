export class AnimationStyles {
  constructor(public styles: {[key: string]: string | number}[]) {}
}
