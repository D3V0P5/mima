// Public API for util
export {Class, ClassDefinition, TypeDecorator} from './util/decorators';
