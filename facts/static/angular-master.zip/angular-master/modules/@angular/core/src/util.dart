library angular2.src.core.util;

// the ts version is needed only for TS, we don't need a Dart implementation
// because there are no decorators in Dart.
