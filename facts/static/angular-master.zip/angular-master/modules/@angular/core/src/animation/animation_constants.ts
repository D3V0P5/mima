export const FILL_STYLE_FLAG = 'true';  // TODO (matsko): change to boolean
export const ANY_STATE = '*';
export const DEFAULT_STATE = '*';
export const EMPTY_STATE = 'void';
