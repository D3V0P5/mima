import {AnimationStyles} from './animation_styles';

export class AnimationKeyframe {
  constructor(public offset: number, public styles: AnimationStyles) {}
}
