// This symbol is not used on the Dart side. This exists just as a stub.
async(Function fn) {
  throw 'async() test wrapper not available for Dart.';
}
