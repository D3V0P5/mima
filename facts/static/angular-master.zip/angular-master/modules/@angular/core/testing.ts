export * from './testing/fake_async';
export * from './testing/lang_utils';
export * from './testing/logger';
export * from './testing/ng_zone_mock';
export * from './testing/regexp';
export * from './testing/test_injector';
export * from './testing/testing';
export * from './testing/mock_application_ref';
